import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
export default function Layout(){return <><StatusBar style="light"/><Stack screenOptions={{
headerStyle:{backgroundColor:"#071B3A"},headerTintColor:"#fff",headerTitleStyle:{fontWeight:"800"}
}}><Stack.Screen name="index" options={{headerShown:false}}/><Stack.Screen name="student" options={{title:"Student Login"}}/><Stack.Screen name="admin" options={{title:"Admin Panel"}}/><Stack.Screen name="setup" options={{title:"Firebase Setup"}}/></Stack></>}