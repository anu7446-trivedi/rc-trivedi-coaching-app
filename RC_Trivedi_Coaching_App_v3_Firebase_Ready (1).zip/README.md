# RC Trivedi Coaching Center v3 — Firebase-ready

This build adds:
- Firebase SDK dependency
- Firestore helper functions for students/notices
- Student login UI
- Admin panel UI
- Firebase setup screen
- JNV, Vidyagyan, Sainik School, Sarvodaya Class 6
- Call/WhatsApp contact
- Generated logo

Backend activation still requires a Firebase project configuration and security rules. Those account-specific credentials cannot be invented. The included `firebaseConfig.example.ts` is the safe template.

Production modules to connect next:
- Firebase Authentication
- Firestore students/tests/results/fees/notices
- Firebase Storage for PDFs
- Admin role protection
- Push notifications
