import { addDoc, collection, getDocs, query, orderBy } from "firebase/firestore";
import { db } from "../firebaseConfig";

export async function addStudent(data:any){
  return addDoc(collection(db,"students"), {...data, createdAt: new Date().toISOString()});
}
export async function getStudents(){
  const snap=await getDocs(query(collection(db,"students"),orderBy("createdAt","desc")));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
}
export async function addNotice(data:any){
  return addDoc(collection(db,"notices"), {...data, createdAt:new Date().toISOString()});
}
export async function getNotices(){
  const snap=await getDocs(query(collection(db,"notices"),orderBy("createdAt","desc")));
  return snap.docs.map(d=>({id:d.id,...d.data()}));
}